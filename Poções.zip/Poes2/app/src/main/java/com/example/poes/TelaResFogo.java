package com.example.poes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TelaResFogo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_res_fogo);
    }
}