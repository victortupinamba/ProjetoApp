package com.example.poes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TelaAgilidade extends AppCompatActivity {

    private Button btn_voltar2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_agilidade);

        btn_voltar2 = findViewById(R.id.btn_voltar2);
        btn_voltar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent_volta2 = new Intent (TelaAgilidade.this,Principal.class);
                startActivity(intent_volta2);
            }
        });
    }
}