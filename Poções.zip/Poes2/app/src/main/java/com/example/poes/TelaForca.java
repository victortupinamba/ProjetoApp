package com.example.poes;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class TelaForca extends AppCompatActivity {

    private Button btn_voltar4;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_forca);

        btn_voltar4 = findViewById(R.id.btn_voltar4);
        btn_voltar4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent_volta4 = new Intent (TelaForca.this,Principal.class);
                startActivity(intent_volta4);
            }
        });
    }
}