package com.example.poes;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.net.Uri;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Principal extends AppCompatActivity {

    private Button btn_invis,btn_regen,btn_agilidade,btn_forca,btn_resfogo,btn_Baixar,btn_Assistir,btn_Ler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);

        Button btn_Baixar = findViewById(R.id.btn_Baixar);

        btn_Baixar = (Button) this.findViewById(R.id.btn_Baixar);
        btn_Baixar.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("https://play.google.com/store/apps/details?id=com.mojang.minecraftpe");
                Intent it = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(it);
            }
        });

        Button btn_Assistir = findViewById(R.id.btn_Assistir);

        btn_Assistir = (Button) this.findViewById(R.id.btn_Assistir);
        btn_Assistir.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("https://youtu.be/b56kfLH9VKY");
                Intent it = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(it);
            }
        });

        Button btn_Ler = findViewById(R.id.btn_Ler);

        btn_Ler = (Button) this.findViewById(R.id.btn_Ler);
        btn_Ler.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("https://tecnoblog.net/responde/como-fazer-pocoes-no-minecraft-tipos-efeitos-e-usos/");
                Intent it = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(it);
            }
        });

        btn_invis = findViewById(R.id.btn_Invis);
        btn_invis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent_invis = new Intent (Principal.this,TelaInvis.class);
                startActivity(intent_invis);
            }
        });

        btn_regen = findViewById(R.id.btn_Regen);
        btn_regen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent_regen = new Intent (Principal.this,TelaRegeneracao.class);
                startActivity(intent_regen);
            }
        });

        btn_agilidade = findViewById(R.id.btn_Agilidade);
        btn_agilidade.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent_agilidade = new Intent (Principal.this,TelaAgilidade.class);
                startActivity(intent_agilidade);
            }
        });

        btn_forca = findViewById(R.id.btn_Forca);
        btn_forca.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent_forca = new Intent (Principal.this,TelaForca.class);
                startActivity(intent_forca);
            }
        });

        btn_resfogo = findViewById(R.id.btn_ResFogo);
        btn_resfogo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent_resfogo = new Intent (Principal.this,TelaResFogo.class);
                startActivity(intent_resfogo);
            }
        });
    }
}